For this project Python 11 is used
File is voronoi_generator.py, imports in this file should be installed using pip
I worked this program in DataSpell of JetBrains, and used the Python Console for matplotlib to run properly
"%matplotlib qt" statement should be entered to console for it to display the plot in a new window and show algorithm step by step.

After running the file on console the inputs should be entered to the console:
    -In the first input, number of points is asked

    -In the second input, distribution is asked with 3 options:
        enter "1" for uniform
        enter "2" for random
        enter "3" for gaussian

    -In the third input, algorithm is asked
        enter "1" for randomized incremental
        enter "2" for flipping

After these inputs, program should display the delaunay triangulation step by step and then it should plot the Voronoi diagram using created Delaunay triangulation.